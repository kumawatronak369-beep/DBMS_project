async function loadDeviceActivity(deviceId) {
    const modal = document.getElementById("deviceActivityModal");
    const details = document.getElementById("deviceDetailsContent");
    const table = document.getElementById("deviceActivityTable");

    modal.style.display = "block";
    details.innerHTML = "Loading device activity...";
    table.innerHTML = "";

    try {
        const response = await fetch(
            `/api/v1/dashboard/devices/${deviceId}/activity`,
            { method:"GET", cache:"no-store", headers:{"Accept":"application/json"} }
        );

        if (!response.ok) {
            throw new Error("Device Activity API HTTP " + response.status);
        }

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || "Unable to load device activity");
        }

        const device = data.device || {};
        const statistics = data.statistics || {};
        const protocolStatistics = data.protocol_statistics || [];
        const activity = data.recent_activity || [];

        document.getElementById("deviceModalTitle").textContent =
            device.hostname || "Device Activity";

        details.innerHTML = `
            <div class="device-info-large-grid">
                <div><strong>IP:</strong><br>${escapeHtml(device.device_ip)}</div>
                <div><strong>Type:</strong><br>${escapeHtml(device.device_type)}</div>
                <div><strong>Gateway:</strong><br>${escapeHtml(device.gateway_node)}</div>
                <div><strong>Status:</strong><br>${escapeHtml(device.status)}</div>
                <div><strong>Last Seen:</strong><br>${escapeHtml(device.last_seen)}</div>
                <div><strong>Device ID:</strong><br>${escapeHtml(device.device_id)}</div>
            </div>

            <div class="device-details">
                <div class="detail-card">
                    <div class="detail-label">Total Events</div>
                    <div class="detail-value">${escapeHtml(statistics.total_events)}</div>
                </div>
                <div class="detail-card">
                    <div class="detail-label">Unique Destinations</div>
                    <div class="detail-value">${escapeHtml(statistics.unique_destinations)}</div>
                </div>
                <div class="detail-card">
                    <div class="detail-label">TCP Events</div>
                    <div class="detail-value">${getProtocolCount(protocolStatistics,"TCP")}</div>
                </div>
                <div class="detail-card">
                    <div class="detail-label">UDP Events</div>
                    <div class="detail-value">${getProtocolCount(protocolStatistics,"UDP")}</div>
                </div>
            </div>
        `;

        if (activity.length === 0) {
            table.innerHTML = `<tr><td colspan="6" style="text-align:center">No recent activity</td></tr>`;
            return;
        }

        activity.forEach(event => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${escapeHtml(event.access_time)}</td>
                <td>${escapeHtml(event.destination_ip)}</td>
                <td>${escapeHtml(event.domain_name || "-")}</td>
                <td>${escapeHtml(event.protocol || "-")}</td>
                <td>${escapeHtml(event.source_port || "-")}</td>
                <td>${escapeHtml(event.destination_port || "-")}</td>
            `;
            table.appendChild(row);
        });

    } catch (error) {
        console.error("Device activity error:", error);
        details.innerHTML = `
            <div class="error-message" style="display:block">
                Unable to load device activity: ${escapeHtml(error.message)}
            </div>
        `;
    }
}

function getProtocolCount(statistics, protocol) {
    const item = statistics.find(
        entry => String(entry.protocol || "").toUpperCase() === protocol
    );
    return item ? item.event_count : 0;
}

function closeDeviceActivity() {
    document.getElementById("deviceActivityModal").style.display = "none";
}

window.addEventListener("click", function(event) {
    const modal = document.getElementById("deviceActivityModal");
    if (event.target === modal) closeDeviceActivity();
});


/* ============================================================
   MANUAL REFRESH
   ============================================================ */

