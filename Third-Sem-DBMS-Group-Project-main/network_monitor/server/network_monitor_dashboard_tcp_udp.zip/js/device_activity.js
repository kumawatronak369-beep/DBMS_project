/* ============================================================
   DEVICE ACTIVITY
   ============================================================ */

function manualRefresh() {

    loadDashboard();

}



/* ============================================================
   HTML ESCAPING
   ============================================================ */

function escapeHtml(value) {


    if (
        value === null ||
        value === undefined
    ) {

        return "-";
    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}



/* ============================================================
   INITIAL LOAD
   ============================================================ */

loadDashboard();



/* ============================================================
   AUTOMATIC REFRESH
   ============================================================ */

setInterval(
    loadDashboard,
    REFRESH_INTERVAL
);


console.log(
    "Dashboard auto-refresh enabled."
);


console.log(
    "Refresh interval:",
    REFRESH_INTERVAL,
    "ms"
);

